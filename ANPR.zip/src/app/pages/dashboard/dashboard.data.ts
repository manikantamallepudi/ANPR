export const analyticsData = [
  {
    name: 'bike',
    series: [
      {
        name: '0',
        value: 0
      },
      {
        name: '1',
        value: 0
      },
      {
        name: '2',
        value: 0
      },
      {
        name: '3',
        value: 0
      },
      {
        name: '4',
        value: 0
      },
      {
        name: '5',
        value: 0
      },
      {
        name: '6',
        value: 0
      },
      {
        name: '7',
        value: 0
      }
    ]
  },
  {
    name: 'car',
    series: [
      {
        name: '0',
        value: 0
      },
      {
        name: '1',
        value: 0
      },
      {
        name: '2',
        value: 0
      },
      {
        name: '3',
        value: 0
      },
      {
        name: '4',
        value: 0
      },
      {
        name: '5',
        value: 0
      },
      {
        name: '6',
        value: 0
      },
      {
        name: '7',
        value: 0
      }
    ]
  }
]

export const disk_space = [
  {
    "name": "No Entry",
    "value": 200
  },
  {
    "name": "Entry",
    "value": 0
  },
  {
    "name": "Exit",
    "value": 0
  }
]

