import { PlateImageDialogComponent } from './platereport-dialog/platereport-dialog.component';
import { ImageDialogComponent } from './report-dialog/report-dialog.component';
import { environment } from './../../../environments/environment.prod';
import { Settings } from './../../app.settings.model';
import { AppSettings } from './../../app.settings';
import { Component, ViewChild, HostListener, AfterViewInit, OnInit } from '@angular/core';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { CommonServices } from '../../services/common.services';
import { GlobalServices } from '../../services/global.service';
import { MatDialog } from '@angular/material';
import { Subscription, interval, Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import * as moment from 'moment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { VehicleNumberDialogComponent } from './vehicleno-dialog/vehicleno-dialog.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'DD/MM/YYYY',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export interface Regno {
  vehicle_reg_no: string;
}

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
})
export class ReportsComponent implements OnInit, AfterViewInit {

  anprList: any = [];

  pdfDoc: any;

  regnos: Observable<Regno[]>;
  myControl = new FormControl();
  options: Regno[] = []

  dataloading: boolean;

  public pageSize = 25;
  public currentPage = 0;
  public totalSize = 0;

  pageSizeOptions: number[];

  updateSubscription: Subscription;

  emptyData: string = "No Records Found";

  //path: any = "http://testfpa.gits.lan/app/";

  path: any = environment.API_URL;

  isDisabledDate: boolean = false;
  isDisabledDateTime: boolean = false;

  public max;
  public maxDate: any = new Date();

  entry_icon = "entry";
  exit_icon = "exit";

  bikeChecked: boolean = false;
  carChecked: boolean = false;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  public displayedColumns = ['date', 'vehicle_reg_no', 'vehicle_licence_no', 'vehicle_type', 'vehicle_in_time', 'vehicle_image', 'number_plate_image'];

  public settings: Settings;

  data: any = {};
  public todayDate: any = new Date();
  anprListData: any=[];
  date1: FormControl;

  date = new Date();
  ngModelDate: Date;


  constructor(public appSettings: AppSettings,
    private commonService: CommonServices,
    private globalService: GlobalServices,
    public dialog: MatDialog) {
    this.settings = this.appSettings.settings;

    //this.pageSizeOptions = this.globalService.pageSizeOptions;

/*     this.data = {
      car: false,
      bike: false,
      entry: false,
      exit: false
    } */

  }

  ngOnInit() {
    this.anprList.paginator = this.paginator;
    this.data.date = new Date();
    this.paginationData();
    let dateFormat = moment(this.data.date).format('YYYY-MM-DD');
    let dataObj = {
      date: dateFormat
    }

    this.getVehicleList(dataObj);

    this.regnos = this.myControl.valueChanges
      .pipe(
        startWith<string | Regno>(''),
        map(value => typeof value === 'string' ? value : value.vehicle_reg_no),
        map(name => name ? this._filter(name) : this.options.slice())
      );

      this.getDataMessage();
    
  }

  onDate(ev) {

    let date = ev.value;
    this.data.range = "";

    let dateFormat = moment(date).format('YYYY-MM-DD');

    let dataObj = {
      "date": dateFormat,
      "reg_number": this.data.reg_number || '',
      "from_time": '',
      "to_time": ''
    }

    this.getVehicleList(dataObj);

  }

  onStartDateSelect(event) {

    let fromDate;
    let toDate;

    if (event.value[0] != null && event.value[1] != null) {
      this.data.date = "";

      fromDate = moment(event.value[0]).format('YYYY-MM-DD HH:mm:ss');
      toDate = moment(event.value[1]).format('YYYY-MM-DD HH:mm:ss');

      let dataObj = {
        "date": '',
        "from_time": fromDate || '',
        "to_time": toDate || ''
      }

      this.getVehicleList(dataObj);
    } else {
      fromDate = "";
      toDate = "";
      this.globalService.showMessage("From Date and To Date field are mandatory")
    }

  }

  showBikeData(event) {

    this.getCheckboxChange();

  }

  showCarData(event) {

    this.getCheckboxChange();
  }

  showEntryData(event) {

    this.getCheckboxChange();

  }

  showExitData(event) {

    this.getCheckboxChange();
  }

  getCheckboxChange() {
    let range = this.data.range;
    let dateFormat;

    console.log(this.data.date)

    let fromDate, toDate;

    if (this.data.date == undefined || this.data.date == '') {
      dateFormat = '';
    } else {
      dateFormat = moment(this.data.date).format('YYYY-MM-DD');
    }

    if (this.data.range == undefined) {
      fromDate = '';
      toDate = '';
    } else {
      fromDate = moment(range[0]).format('YYYY-MM-DD HH:mm:ss');
      toDate = moment(range[1]).format('YYYY-MM-DD HH:mm:ss');
    }

    let dataObj;

    if (this.data.date == undefined || this.data.date == undefined) {
      //console.log("category")
      dataObj = {
        "date": '',
        "from_time": '',
        "to_time": '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit
      }
    } else if (this.data.range == '') {
      //console.log("date")
      dataObj = {
        "date": dateFormat || '',
        "from_time": '',
        "to_time": '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit
      }
    } else {
      dataObj = {
        "date": '',
        "from_time": fromDate || '',
        "to_time": toDate || '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit
      }
    }

    //console.log(dataObj);
    this.getVehicleList(dataObj);
  }

  public handlePage(e: any) {
    //console.log(e)

    this.currentPage = e.pageIndex;
    this.pageSize = e.pageSize;


    let range = this.data.range;
    let dateFormat;

    let fromDate, toDate;

    if (this.data.date == undefined || this.data.date == '') {
      dateFormat = '';
    } else {
      dateFormat = moment(this.data.date).format('YYYY-MM-DD');
    }

    if (this.data.range == undefined) {
      fromDate = '';
      toDate = '';
    } else {
      fromDate = moment(range[0]).format('YYYY-MM-DD HH:mm:ss');
      toDate = moment(range[1]).format('YYYY-MM-DD HH:mm:ss');
    }

    let dataObj;

    if (this.data.date == undefined || this.data.date == undefined) {
      //console.log("category")
      dataObj = {
        "date": '',
        "from_time": '',
        "to_time": '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit,
        "size": e.pageSize,
        "offset": e.pageIndex + 1
      }
    } else if (this.data.range == '') {
      //console.log("date")
      dataObj = {
        "date": dateFormat || '',
        "from_time": '',
        "to_time": '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit,
        "size": e.pageSize,
        "offset": e.pageIndex + 1
      }
    } else {
      dataObj = {
        "date": '',
        "from_time": fromDate || '',
        "to_time": toDate || '',
        "bike": this.data.bike,
        "car": this.data.car,
        "entry": this.data.entry,
        "exit": this.data.exit,
        "size": e.pageSize,
        "offset": e.pageIndex + 1
      }
    }

    this.getVehicleList(dataObj);
  }


  getVehicleList(data: any) {

    //console.log(data);
    //console.log(data.size, data.offset)
    //console.log(this.pageSize, this.currentPage + 1)

    this.anprList = [];
    
    this.emptyData = "Loading..";

    let obj;

    obj = {
      "date": data.date || '',
      "reg_number": data.reg_number || this.data.reg_number || "",
      "from_time": data.from_time || '',
      "to_time": data.to_time || '',
      "bike": data.bike || this.data.bike || false,
      "car": data.car || this.data.car || false,
      "entry": data.entry || this.data.entry || false,
      "exit": data.exit || this.data.exit || false,
      "size_of_page": data.size || 25,
      "offset": data.offset || 1
    };

    this.commonService.getReportList(obj).subscribe((res) => {
      if (res['success'] == 1) {

        this.anprList = new MatTableDataSource(res["data"]);
        this.anprListData = res["data"];
        this.totalSize = res["count"];
        this.pdfDoc = res['file_path'];

        this.paginationData();

        if (this.totalSize == 0) {
          this.dataloading = false;
          this.emptyData = "No Records Found";
        } else if (this.totalSize < 25) {
          this.currentPage = 0;
          this.dataloading = true;
        } else {
          this.dataloading = true;
        }
      }
      else {

        //this.emptyData = "No Records Found";
        this.dataloading = false;
        this.globalService.showErrorMessage(res['message'])
      }
    },
      (err) => {
        this.dataloading = false;
        console.log(err);
      })
  }

  getDataMessage(){
    if(this.anprList.data.length == 0){
      this.emptyData = "No Records Found";
    }else{
      this.emptyData = "Loading";
    }
  }

  paginationData(){
    if(this.totalSize <= 25){
      this.pageSizeOptions = [25];
    }else if(this.totalSize > 100){
      this.pageSizeOptions = [25, 50, 100];
    }else if(this.totalSize > 25 || this.totalSize <= 50){
      this.pageSizeOptions = [25, 50];
    }else{
      this.pageSizeOptions = [25, 50, 100];
    }
  }

  ngAfterViewInit() {
    this.anprList.paginator = this.paginator;
  }

  displayFn(user) {
    return user;
  }

  vehicleDataChanged(newObj) {

    let dateFormat;

    if (this.data.date == undefined) {
      dateFormat = '';
    } else {
      dateFormat = moment(this.data.date).format('YYYY-MM-DD');
    }

    let strFirstThree = newObj.length;
    let range = this.data.range;

    //console.log(strFirstThree);
    //console.log(range);

    if (strFirstThree >= 3) {
      let dataObj;
      if (range == undefined || dateFormat == "") {
        dataObj = {
          "date": '',
          "from_time": '',
          "to_time": '',
          "reg_number": newObj || ''
        }
      } else if (range == "") {
        dataObj = {
          "date": dateFormat || '',
          "from_time": '',
          "to_time": '',
          "reg_number": newObj || ''
        }
      } else {
        let fromDate = moment(range[0]).format('YYYY-MM-DD HH:mm:ss');
        let toDate = moment(range[1]).format('YYYY-MM-DD HH:mm:ss');
        dataObj = {
          "date": '',
          "from_time": fromDate || '',
          "to_time": toDate || '',
          "reg_number": newObj || ''
        }
      }

      this.getVehicleList(dataObj);

    } else if (strFirstThree == 0) {
      let dataObj;
      if (range == undefined || dateFormat == "") {
        dataObj = {
          "date": '',
          "from_time": '',
          "to_time": '',
          "reg_number": newObj || ''
        }
      } else if (range == "") {
        dataObj = {
          "date": dateFormat,
          "from_time": '',
          "to_time": '',
          "reg_number": newObj || ''
        }
      } else {
        let fromDate = moment(range[0]).format('YYYY-MM-DD HH:mm:ss');
        let toDate = moment(range[1]).format('YYYY-MM-DD HH:mm:ss');
        dataObj = {
          "date": '',
          "from_time": fromDate || '',
          "to_time": toDate || '',
          "reg_number": newObj || ''
        }
      }

      this.getVehicleList(dataObj);

    }

  }

  dataChanged(newObj) {

    let obj = {
      "vehicle_reg_no": newObj
    }
    this.commonService.getRegnoDropdown(obj).subscribe(
      res => {
        if (res['success'] == 1) {
          this.options = res['data'];
        } else {
          this.options = [];
          this.getVehicleList({});
        }
      },
      err => {
        console.log(err);
      });
  }

  selectRegnoOption(value) {

    let regno = value.vehicle_reg_no;

    let dateFormat;

    if (this.data.date == undefined) {
      dateFormat = '';
    } else {
      dateFormat = moment(this.data.date).format('YYYY-MM-DD');
    }

    let dataObj = {
      "date": dateFormat,
      "reg_number": regno || ''
    }

    this.getVehicleList(dataObj);
  }

  private _filter(name: string): Regno[] {
    const filterValue = name.toLowerCase();
    return this.options.filter(option => option.vehicle_reg_no.toLowerCase().indexOf(filterValue) === 0);
  }

  openDialog(element): void {
    let dialogRef = this.dialog.open(ImageDialogComponent, {
      /*  maxWidth: '100vw !important', */
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  openDialog1(element): void {
    let dialogRef = this.dialog.open(PlateImageDialogComponent, {
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  openVehicleNoDialog(element): void {
    let dialogRef = this.dialog.open(VehicleNumberDialogComponent, {
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  docdownload() {
    if (this.pdfDoc != undefined) {
      let link = document.createElement("a");
      link.download = 'Report';
      let res = environment.API_URL + this.pdfDoc;
      link.href = res;
      window.open(res, '_blank');
    } else {
      this.globalService.showErrorMessage("No File Found");
    }
  }

}