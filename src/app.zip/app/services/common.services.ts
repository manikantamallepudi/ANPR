import { Injectable } from '@angular/core';
import { GlobalServices } from './global.service';
import { HttpServices } from './http.services';

@Injectable()
export class CommonServices {

    constructor(private http: HttpServices, private globalServices: GlobalServices) { }

    getDashboardCount(obj) {
        let url = this.globalServices.ApiUrls().getDashboardCount;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }

    getCompanyList(obj) {
        let url = this.globalServices.ApiUrls().getCompanyList;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    getCameraList(obj) {
        let url = this.globalServices.ApiUrls().getCameraList;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    addCompany(obj) {
        let url = this.globalServices.ApiUrls().addCompany;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    addCamera(obj) {
        let url = this.globalServices.ApiUrls().addCamera;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    editCamera(obj) {
        let url = this.globalServices.ApiUrls().editCamera;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    editCompany(obj) {
        let url = this.globalServices.ApiUrls().editCompany;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    deleteCompany(obj) {
        let url = this.globalServices.ApiUrls().deleteCompany;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    deleteCamera(obj) {
        let url = this.globalServices.ApiUrls().deleteCamera;
        return this.http.HttpRequest({ url, method: 'P', data: obj, ...obj });
    }

    getReportList(obj) {
        let url = this.globalServices.ApiUrls().getReportList;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    getDashboardVehicleList(obj) {
        let url = this.globalServices.ApiUrls().getDashboardVehicleList;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }

    getRegnoDropdown(obj) {
        let url = this.globalServices.ApiUrls().getRegnoDropdown;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    activityLog(obj) {
        let url = this.globalServices.ApiUrls().activityLog;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }



    getAppUrl(obj) {
        let url = this.globalServices.ApiUrls().getAppUrl;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    getMenulist(obj) {
        let url = this.globalServices.ApiUrls().getMenulist;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    recentupdates(obj) {
        let url = this.globalServices.ApiUrls().activityLog
        return this.http.HttpRequest({ url, method: 'G', ...obj })
    }

    dailyReportGraphs(obj) {
        let url = this.globalServices.ApiUrls().dailyReportGraphs;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }

    monthlyReportGraphs(obj) {
        let url = this.globalServices.ApiUrls().monthlyReportGraphs;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }

    yearlyReportGraphs(obj) {
        let url = this.globalServices.ApiUrls().yearlyReportGraphs;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }

    getPieSearchData(obj) {
        let url = this.globalServices.ApiUrls().getPieSearchData;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    graphsVehicleData(obj) {
        let url = this.globalServices.ApiUrls().graphsVehicleData;
        return this.http.HttpRequest({ url, method: 'G', params: obj, ...obj });
    }

    getRecurringCount(obj) {
        let url = this.globalServices.ApiUrls().getRecurringCount;
        return this.http.HttpRequest({ url, method: 'G', ...obj });
    }
}