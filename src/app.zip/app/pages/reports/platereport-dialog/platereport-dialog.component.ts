import { environment } from './../../../../environments/environment.prod';
import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-platereport-dialog',
  templateUrl: './platereport-dialog.component.html',
  styleUrls: ['./platereport-dialog.component.scss']
})
export class PlateImageDialogComponent implements OnInit {
  vehicleurl: any;

  //path: any = "http://testfpa.gits.lan/app/";
  path: any = environment.API_URL;
  
  constructor(public dialogRef: MatDialogRef<PlateImageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      console.log(data)

      //this.vehicleurl = environment.API_URL+data.vehicle_image;
      this.vehicleurl = this.path+data.number_plate_image;
    }

  ngOnInit() {
  }
  

  dialogClose(){
    this.dialogRef.close();
  }
}
