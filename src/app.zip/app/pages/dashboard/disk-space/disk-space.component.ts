import { GlobalServices } from './../../../services/global.service';
import { CommonServices } from './../../../services/common.services';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-disk-space',
  templateUrl: './disk-space.component.html'
})
export class DiskSpaceComponent implements OnInit {
  public data: any[];
  public showLegend = false;
  public gradient = true;
  public colorScheme = {
    domain: ['#378D3B', '#2F3E9E']
  };
  model: any;
  vehicle_reg_no: any;
  public showLabels = true;
  public explodeSlices = true;
  public doughnut = false;
  @ViewChild('resizedDiv', { static: true }) resizedDiv: ElementRef;
  public previousWidthOfResizedDiv: number = 0;

  constructor(private commonService: CommonServices, private globalService: GlobalServices) { }

  ngOnInit() {

    this.dashboardCount();

  }

  dashboardCount() {

    let obj = {};

    this.commonService.getDashboardCount(obj).subscribe((res) => {
      if (res["success"] == 1) {
        let obj = res["data"];

        this.data = [
          {
            "name": "Entry",
            "value": obj.entry
          },
          {
            "name": "Exit",
            "value": obj.exit
          }
        ];

        console.log(obj);
        console.log(this.data);


      }
    })
  }

  vehicleDataChanged(newObj) {
    
    if (newObj == undefined || newObj == '') {
      this.dashboardCount();
      //this.globalService.showMessage("Enter Vehicle No.")
    } else {
      let obj = {
        "vehicle_reg_no": newObj
      }
      this.commonService.getPieSearchData(obj).subscribe(res => {

        this.data = [
          {
            "name": "Entry",
            "value": res["entry"]
          },
          {
            "name": "Exit",
            "value": res["exit"]
          }
        ];

        console.log(this.data)


      },
        err => {
          console.log(err);
        });
    }
  }

  public onSelect(event) {
    console.log(event);
  }

  ngAfterViewChecked() {
    if (this.previousWidthOfResizedDiv != this.resizedDiv.nativeElement.clientWidth) {
      setTimeout(() => this.data = [...this.data]);
    }
    this.previousWidthOfResizedDiv = this.resizedDiv.nativeElement.clientWidth;
  }

}