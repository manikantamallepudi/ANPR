import { GlobalServices } from './../../../services/global.service';
import { CommonServices } from './../../../services/common.services';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tiles',
  templateUrl: './tiles.component.html',
  styleUrls: ['./tiles.component.scss']
})
export class TilesComponent implements OnInit {

  data: any = {};

  constructor(private commonService: CommonServices, private globalService: GlobalServices) {
    this.dashboardCount();
    //this.dashboardRecurringCount();
   }

  ngOnInit() {
    
    
  }

  dashboardCount() {

    let obj = {};

    this.commonService.getDashboardCount(obj).subscribe((res) => {
      if (res["success"] == 1) {
        this.data = res["data"];
      } 
    })
  }

  /* dashboardRecurringCount() {

    let obj = {};

    this.commonService.getRecurringCount(obj).subscribe((res) => {
      if (res["success"] == 1) {
     
        this.data.recurring = res["recurring"];
        console.log("recurring: "+res["recurring"]);
      } 
    })
  } */

}
