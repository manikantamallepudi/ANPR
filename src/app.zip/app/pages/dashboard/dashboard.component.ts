import { GlobalServices } from './../../services/global.service';
import { CommonServices } from './../../services/common.services';
import * as moment from 'moment';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

export interface Analysis {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  data: any = {};

  public maxDate: any = new Date();

  public analytics: any[];
  public showXAxis = true;
  public showYAxis = true;
  public gradient = false;
  public showLegend = false;
  public showXAxisLabel = true;
  public xAxisLabel;
  public showYAxisLabel = true;
  public yAxisLabel = 'Vehicle Count';
  public colorScheme = {
    domain: ['#283593', '#FF4F00']
  }; 
  public autoScale = true;
  public roundDomains = true;
  @ViewChild('resizedDiv', {static: true}) resizedDiv:ElementRef;
  public previousWidthOfResizedDiv:number = 0; 


  analysisData: Analysis[] = [
    {value: 'hourly', viewValue: 'Hourly'},
    {value: 'daily', viewValue: 'Daily'},
    {value: 'monthly', viewValue: 'Monthly'},
    {value: 'yearly', viewValue: 'Yearly'}
  ];

  constructor(private commonService: CommonServices, private globalService: GlobalServices) { 

    let dateValue = new Date();

    this.data = {
      type: 'hourly',
      date: dateValue
    }
    
    this.GraphsVehicleData(this.data);

    this.xAxisLabelData();
  
  }

  ngOnInit() {
    
  }

  xAxisLabelData(){
    if(this.data.type == 'hourly'){
      this.xAxisLabel = "Hours"
    }else if(this.data.type == 'daily'){
      this.xAxisLabel = "Days"
    }else if(this.data.type == 'monthly'){
      this.xAxisLabel = "Months"
    }else if(this.data.type == 'yearly'){
      this.xAxisLabel = "Years"
    }
  }

  selectCategory(ev){
    this.xAxisLabelData();

    console.log(ev.type)

    let data = {
      type: ev.type,
      date: this.data.date
    }
    this.GraphsVehicleData(data);
  }

  onDate(ev) {

    let data = {
      type: this.data.type,
      date: ev.value
    }

    this.GraphsVehicleData(data);

  }

  GraphsVehicleData(obj) {

    let dateObj = moment(obj.date).format('YYYY-MM-DD');

    let data = {
      type: obj.type,
      date: dateObj
    }

    this.commonService.graphsVehicleData(data).subscribe((res) => {
      if (res["success"] == 1) {
        this.analytics = res["data"]; 
        //console.log(res["data"]);
      }else{

      }
    })
  }

  onSelect(event) {
    console.log(event);
  }

  ngAfterViewChecked() {    
    if(this.previousWidthOfResizedDiv != this.resizedDiv.nativeElement.clientWidth){
      this.analytics = [...this.analytics];
    }
    this.previousWidthOfResizedDiv = this.resizedDiv.nativeElement.clientWidth;
  }

  

}
