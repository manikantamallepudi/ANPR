export class Company {
    id: number;
    company_name: string;
    company_location: string;
    company_added_time: Date;
    company_logo: string;
}