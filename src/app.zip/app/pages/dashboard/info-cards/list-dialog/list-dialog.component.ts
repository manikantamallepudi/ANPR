import { ImageDialogComponent } from './../../../reports/report-dialog/report-dialog.component';
import { CommonServices } from './../../../../services/common.services';
import { GlobalServices } from './../../../../services/global.service';
import { environment } from './../../../../../environments/environment';
import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatPaginator, MatDialog } from '@angular/material';
import * as moment from 'moment';

@Component({
  selector: 'app-list-dialog',
  templateUrl: './list-dialog.component.html',
  styleUrls: ['./list-dialog.component.scss']
})
export class GraphListDialogComponent implements OnInit {
  vehicleurl: any;

  //path: any = "http://testfpa.gits.lan/app/";
  path: any = environment.API_URL;

  anprList: any = [];
  totalRecords: any;
  dataloading: boolean;

  pageSizeOptions: any = [10];
  pageSize: number;

  entry_icon = "entry";
  exit_icon = "exit";


  emptyData: string = "No Records Found";


  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  public displayedColumns = ['date', 'vehicle_status', 'vehicle_licence_no', 'vehicle_type', 'vehicle_in_time', 'vehicle_image', 'number_plate_image'];


  constructor(public dialog: MatDialog, public dialogRef: MatDialogRef<GraphListDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data1: any, private commonService: CommonServices,
    private globalService: GlobalServices) {
    console.log(data1)

    //this.vehicleurl = this.path + this.data.vehicle_image;

    let checkdate = moment(data1.name).format('YYYY-MM-DD');

    console.log(data1);

    let dataObj = {
      "date": checkdate,
    }

    this.getVehicleList(dataObj);

  }

  getVehicleList(data) {

    this.emptyData = "Loading";

    let size;
    let offset;
    if (data.pageSize != undefined) {
      size = data.pageSize;
      offset = data.pageIndex + 1;
    }
    else {
      size = 10;
      offset = 1;
    }

    let obj;

    obj = {
      "date": data.checkdate,
      "reg_number": "",
      "from_time": "",
      "to_time": "",
      "bike": true,
      "car": true, 
      "entry": true,
      "exit": true, 
      "size_of_page": size,
      "offset": offset
    };

    this.commonService.getReportList(obj).subscribe((res) => {
      if (res['success'] == 1) {

        this.anprList = res["data"];
        console.log(this.anprList);


        this.totalRecords = res["count"];

        if (this.totalRecords == 0) {
          this.dataloading = false;
          this.emptyData = "No Records Found";
        } else {
          this.dataloading = true;
        }
      }
      else {

        this.emptyData = "No Records Found";
        this.dataloading = false;
        this.globalService.showErrorMessage(res['message'])
      }
    },
      (err) => {
        this.dataloading = false;
        console.log(err);
      })
  }

  ngOnInit() {
  }

  openDialog(element): void {
    let dialogRef = this.dialog.open(ImageDialogComponent, {
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }


  dialogClose() {
    this.dialogRef.close();
  }
}
