export class Camera {
    id: number;
    camera_id: string;
    camera_location: string;
    camera_name: Date;
    camera_ip: string;
    company_name: string;
}