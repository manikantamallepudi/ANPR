declare var baseUrl :any;
declare var ssoUrl :any;

export const environment = {
  production: true,
  API_URL : baseUrl,
  SSO_URL : ssoUrl,
};
