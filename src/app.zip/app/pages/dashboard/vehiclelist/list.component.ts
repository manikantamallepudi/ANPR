import { GlobalServices } from './../../../services/global.service';
import { CommonServices } from './../../../services/common.services';
import { TablesService } from '../../tables/tables.service';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { AppSettings } from '../../../app.settings';
import { Settings } from '../../../app.settings.model';
import { Subscription, interval } from 'rxjs';
import { environment } from 'src/environments/environment';

export interface Element {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}


@Component({
  selector: 'app-todo',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  providers: [TablesService]
})
export class TodoComponent implements OnInit{
  public todoList: Array<any>;
  public newTodoText: string = '';

  public displayedColumns = ['vehicle_in_time', 'vehicle_reg_no', 'vehicle_image', 'number_plate_image'];
  public dataSource: any;
  public settings: Settings;

  entry_icon = "entry";
  exit_icon = "exit";



  path: any = environment.API_URL;
  //path: any = "http://testfpa.gits.lan/app/";

  private updateSubscription: Subscription;

  constructor(public appSettings: AppSettings, private commonService: CommonServices,
    private globalService: GlobalServices) {
    this.settings = this.appSettings.settings;
    //this.dataSource = new MatTableDataSource<Element>(this.tablesService.getData());

    this.getVehicleList();

    this.updateSubscription = interval(300000).subscribe(
      (val) => {
        console.log(val);
        this.getVehicleList();
      }
    )
  }

  ngOnInit() {
    /* this.dataSource.filterPredicate = (data: Element, filter: string) => {
      console.log(data)
      return data.name == filter;
     }; */
   }

  getVehicleList() {
    let obj = {};
    this.commonService.getDashboardVehicleList(obj).subscribe((res) => {
      if (res['success'] == 1) {
        this.dataSource = new MatTableDataSource(res["data"]);
        
      }
      else {
        this.globalService.showErrorMessage(res['message'])
      }
    },
      (err) => {

        console.log(err);
      })
  }

  applyFilter(filterValue: string) {
    //this.dataSource.filter = filterValue.trim().toLowerCase();
    //this.dataSource.filter = filterValue;

    let strFirstThree = filterValue.length;

    if (strFirstThree >= 3) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }else if (strFirstThree == 0) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }

    //console.log(filterValue)
  }


}
